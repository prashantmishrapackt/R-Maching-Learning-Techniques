### R Machine Learning by Example ###

This bundle consists of all the algorithms, models code and datasets which have been used in the book. 

For hardware and software requirements please refer to "software hardware list.docx"

Each chapter has its own code files and you can access them under the "Code" directory

The best way to use these files would be to open R and set the working directory to the chapter which you might be
interested in and as you follow along the book, you can execute the same code in your system to gain hands-on experience
along with learning the concepts and techniques.

